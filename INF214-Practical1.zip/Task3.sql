USE Sales
CREATE TABLE Music.Music(
	Serial_Number int PRIMARY KEY NOT NULL, 
	CategoryID VARCHAR(50),
	Rental_CatID VARCHAR(50),
	Rental_Code VARCHAR(50),
	Album_Title VARCHAR(50),
);

USE Sales
CREATE TABLE Music.Ratings(
	RateCode int PRIMARY KEY NOT NULL,
	RateDescription VARCHAR(50),
);

USE Sales
CREATE TABLE Category.Music_Category(
	CategoryID int PRIMARY KEY NOT NULL,
	Category_Name VARCHAR(50),
	Category_Description VARCHAR(50),
	FanBase VARCHAR(50),
);

USE Sales
CREATE TABLE Category.Rental_Category(
	Rental_CatID int PRIMARY KEY NOT NULL,
	Rental_Cat_Description VARCHAR(50),
	Daily_Rental_Amount VARCHAR(50),
);